class Ch
  implements Runnable
{
  Ch(Cf paramCf, Exception paramException) {}
  
  public void run()
  {
    this.b.c.a(this.b.d, this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ch
 * JD-Core Version:    0.7.0.1
 */