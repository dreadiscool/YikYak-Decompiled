import java.io.IOException;

class Bu
  extends zU
{
  Bu(Br paramBr, String paramString, Object[] paramArrayOfObject, boolean paramBoolean, int paramInt1, int paramInt2, Bk paramVarArgs)
  {
    super(paramString, paramArrayOfObject);
  }
  
  public void b()
  {
    try
    {
      Br.a(this.f, this.a, this.c, this.d, this.e);
      label23:
      return;
    }
    catch (IOException localIOException)
    {
      break label23;
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bu
 * JD-Core Version:    0.7.0.1
 */