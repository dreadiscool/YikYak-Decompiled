import android.widget.TextView;

class Dx
  implements Runnable
{
  Dx(Dw paramDw, TextView paramTextView) {}
  
  public void run()
  {
    this.a.setSingleLine(false);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dx
 * JD-Core Version:    0.7.0.1
 */