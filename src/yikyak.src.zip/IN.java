import java.util.Collection;

public abstract interface IN
{
  public abstract Collection<? extends IM> e();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IN
 * JD-Core Version:    0.7.0.1
 */