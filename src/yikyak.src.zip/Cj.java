public abstract interface Cj
{
  public abstract void a(zF paramzF, Object paramObject);
  
  public abstract void a(zz paramzz, Exception paramException);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cj
 * JD-Core Version:    0.7.0.1
 */