import java.util.List;

public abstract interface Bl
{
  public static final Bl a = new Bm();
  
  public abstract void a(int paramInt, AP paramAP);
  
  public abstract boolean a(int paramInt1, LD paramLD, int paramInt2, boolean paramBoolean);
  
  public abstract boolean a(int paramInt, List<AT> paramList);
  
  public abstract boolean a(int paramInt, List<AT> paramList, boolean paramBoolean);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bl
 * JD-Core Version:    0.7.0.1
 */