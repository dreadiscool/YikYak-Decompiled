public abstract interface Kc
{
  public abstract void a(Throwable paramThrowable);
  
  public abstract void b(boolean paramBoolean);
  
  public abstract boolean e();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Kc
 * JD-Core Version:    0.7.0.1
 */