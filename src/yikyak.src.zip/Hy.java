import java.util.Random;

public abstract interface Hy
{
  public abstract void a(Hx paramHx, Random paramRandom);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hy
 * JD-Core Version:    0.7.0.1
 */