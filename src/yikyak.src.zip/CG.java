public class CG
{
  public String a;
  public String b;
  public String c;
  public String d;
  public boolean e;
  public boolean f;
  public boolean g;
  public boolean h;
  public String i;
  public boolean j;
  public boolean k = false;
  public boolean l = false;
  public boolean m = false;
  
  public CG(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2, int paramInt3, int paramInt4)
  {
    this.j = false;
    this.a = paramString1;
    this.b = paramString2;
    this.i = paramString3;
    int i1;
    int i2;
    label70:
    int i3;
    if (paramInt1 == n)
    {
      i1 = n;
      this.e = i1;
      if (paramInt2 != n) {
        break label113;
      }
      i2 = n;
      this.f = i2;
      if (paramInt3 != n) {
        break label119;
      }
      i3 = n;
      label87:
      this.g = i3;
      if (paramInt4 != n) {
        break label125;
      }
    }
    for (;;)
    {
      this.h = n;
      return;
      i1 = 0;
      break;
      label113:
      i2 = 0;
      break label70;
      label119:
      i3 = 0;
      break label87;
      label125:
      n = 0;
    }
  }
  
  public CG(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean)
  {
    this.j = true;
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.i = paramString5;
    this.k = paramBoolean;
    this.e = false;
    this.f = false;
    this.g = false;
    this.h = false;
  }
  
  public boolean a()
  {
    if (this.b == this.a) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CG
 * JD-Core Version:    0.7.0.1
 */