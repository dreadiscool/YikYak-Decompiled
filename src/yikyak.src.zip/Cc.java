public class Cc
  extends BO
{
  protected void b()
  {
    a(new BL("comment", BN.e, new BM[0]));
    a(new BL("commentId", BN.e, new BM[0]));
    a(new BL("content", BN.e, new BM[0]));
    a(new BL("deliveryId", BN.e, new BM[0]));
    a(new BL("hidePin", BN.a, new BM[0]));
    a(new BL("isComment", BN.a, new BM[0]));
    a(new BL("latitude", BN.e, new BM[0]));
    a(new BL("liked", BN.c, new BM[0]));
    a(new BL("linkProvider", BN.e, new BM[0]));
    a(new BL("linkSummary", BN.e, new BM[0]));
    a(new BL("linkTitle", BN.e, new BM[0]));
    a(new BL("linkThumbnailUrl", BN.e, new BM[0]));
    a(new BL("linkUrl", BN.e, new BM[0]));
    a(new BL("longitude", BN.e, new BM[0]));
    a(new BL("numberOfComments", BN.c, new BM[0]));
    a(new BL("numberOfLikes", BN.c, new BM[0]));
    a(new BL("posterId", BN.e, new BM[0]));
    a(new BL("showHandle", BN.a, new BM[0]));
    a(new BL("timePosted", BN.b, new BM[0]));
    a(new BL("type", BN.c, new BM[0]));
    a(new BL("yakId", BN.e, new BM[0]));
    a(new BL("yakkerHandle", BN.e, new BM[0]));
    a(new BL("yakkerId", BN.e, new BM[0]));
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cc
 * JD-Core Version:    0.7.0.1
 */