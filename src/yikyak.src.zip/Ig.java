import java.io.IOException;

class Ig
  implements yZ
{
  Ig(If paramIf) {}
  
  public void a(zF paramzF)
  {
    try
    {
      paramzF.h().f();
      label8:
      return;
    }
    catch (IOException localIOException)
    {
      break label8;
    }
  }
  
  public void a(zz paramzz, IOException paramIOException)
  {
    paramIOException.getMessage();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ig
 * JD-Core Version:    0.7.0.1
 */