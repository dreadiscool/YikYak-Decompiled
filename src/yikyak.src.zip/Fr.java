class Fr
  implements Runnable
{
  Fr(Fp paramFp) {}
  
  public void run()
  {
    this.a.c.g = false;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fr
 * JD-Core Version:    0.7.0.1
 */