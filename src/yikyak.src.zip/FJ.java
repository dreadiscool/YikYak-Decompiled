import java.util.Comparator;

class FJ
  implements Comparator<CK>
{
  FJ(FH paramFH) {}
  
  public int a(CK paramCK1, CK paramCK2)
  {
    return paramCK1.i - paramCK2.i;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FJ
 * JD-Core Version:    0.7.0.1
 */