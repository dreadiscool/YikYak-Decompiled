import android.app.Activity;
import android.os.Bundle;

class ID
  extends IA
{
  ID(IC paramIC) {}
  
  public void a(Activity paramActivity)
  {
    this.a.a(paramActivity);
  }
  
  public void a(Activity paramActivity, Bundle paramBundle)
  {
    this.a.a(paramActivity);
  }
  
  public void b(Activity paramActivity)
  {
    this.a.a(paramActivity);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     ID
 * JD-Core Version:    0.7.0.1
 */