import com.nispok.snackbar.Snackbar;
import com.yik.yak.ui.activity.SendAYak;
import com.yik.yak.ui.view.LinkDetectingEditText;

public class Eg
  implements yE
{
  public Eg(SendAYak paramSendAYak) {}
  
  public void a(Snackbar paramSnackbar)
  {
    SendAYak.i(this.a).clearComposingText();
    SendAYak.c(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Eg
 * JD-Core Version:    0.7.0.1
 */