public enum Db
{
  static
  {
    Db[] arrayOfDb = new Db[2];
    arrayOfDb[0] = a;
    arrayOfDb[1] = b;
    c = arrayOfDb;
  }
  
  private Db() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Db
 * JD-Core Version:    0.7.0.1
 */