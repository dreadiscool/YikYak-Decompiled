public class IK
  extends RuntimeException
{
  public IK(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IK
 * JD-Core Version:    0.7.0.1
 */