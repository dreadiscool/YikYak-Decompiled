import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import java.util.List;

class Gg
  implements AdapterView.OnItemClickListener
{
  Gg(Gd paramGd) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    Gd.a(this.a, null);
    CH localCH = (CH)Gd.d(this.a).get(paramInt);
    if (localCH.a()) {}
    for (;;)
    {
      return;
      Gd.b(this.a, localCH);
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Gg
 * JD-Core Version:    0.7.0.1
 */