public enum Hu
{
  static
  {
    Hu[] arrayOfHu = new Hu[3];
    arrayOfHu[0] = a;
    arrayOfHu[1] = b;
    arrayOfHu[2] = c;
    d = arrayOfHu;
  }
  
  private Hu() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hu
 * JD-Core Version:    0.7.0.1
 */