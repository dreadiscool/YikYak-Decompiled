import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.yik.yak.ui.view.PhotoLinkCardView;
import com.yik.yak.ui.view.PhotoLinkCardView..ViewInjector;

public class Hp
  extends DebouncingOnClickListener
{
  public Hp(PhotoLinkCardView..ViewInjector paramViewInjector, PhotoLinkCardView paramPhotoLinkCardView) {}
  
  public void doClick(View paramView)
  {
    this.a.onClick();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hp
 * JD-Core Version:    0.7.0.1
 */