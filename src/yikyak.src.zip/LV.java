import java.io.Closeable;

public abstract interface LV
  extends Closeable
{
  public abstract long a(Lz paramLz, long paramLong);
  
  public abstract LW b();
  
  public abstract void close();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     LV
 * JD-Core Version:    0.7.0.1
 */