import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import java.io.IOException;

class FE
  implements yZ
{
  Handler a = new Handler(this.c.getActivity().getMainLooper());
  int b = 0;
  
  FE(FB paramFB) {}
  
  public void a(zF paramzF) {}
  
  public void a(zz paramzz, IOException paramIOException) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FE
 * JD-Core Version:    0.7.0.1
 */