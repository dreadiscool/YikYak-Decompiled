import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.SendAYak;

public class DO
  implements View.OnClickListener
{
  public DO(SendAYak paramSendAYak) {}
  
  public void onClick(View paramView)
  {
    SendAYak.o(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DO
 * JD-Core Version:    0.7.0.1
 */