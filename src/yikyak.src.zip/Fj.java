class Fj
  implements Hb
{
  Fj(Fb paramFb) {}
  
  public void a()
  {
    this.a.h();
    this.a.a();
    If.a().l();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fj
 * JD-Core Version:    0.7.0.1
 */