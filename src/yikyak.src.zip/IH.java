public abstract interface IH<T>
{
  public static final IH d = new IJ(null);
  
  public abstract void a(Exception paramException);
  
  public abstract void a(T paramT);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IH
 * JD-Core Version:    0.7.0.1
 */