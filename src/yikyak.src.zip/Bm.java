import java.util.List;

final class Bm
  implements Bl
{
  public void a(int paramInt, AP paramAP) {}
  
  public boolean a(int paramInt1, LD paramLD, int paramInt2, boolean paramBoolean)
  {
    paramLD.g(paramInt2);
    return true;
  }
  
  public boolean a(int paramInt, List<AT> paramList)
  {
    return true;
  }
  
  public boolean a(int paramInt, List<AT> paramList, boolean paramBoolean)
  {
    return true;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bm
 * JD-Core Version:    0.7.0.1
 */