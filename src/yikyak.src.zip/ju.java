import android.location.Location;

public abstract interface ju
{
  public abstract void onLocationChanged(Location paramLocation);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     ju
 * JD-Core Version:    0.7.0.1
 */