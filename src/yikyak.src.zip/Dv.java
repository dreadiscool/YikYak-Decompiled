import java.io.IOException;

class Dv
  implements Runnable
{
  Dv(Dt paramDt, IOException paramIOException) {}
  
  public void run()
  {
    new StringBuilder().append("Failed:").append(this.a.getMessage()).append("").toString();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dv
 * JD-Core Version:    0.7.0.1
 */