public class Ij
{
  private static String a()
  {
    return "drawable-xxhdpi/";
  }
  
  public static String a(String paramString)
  {
    return "https://d3436qb9f9xu23.cloudfront.net/replier/backgrounds/android/" + a() + paramString;
  }
  
  public static String b(String paramString)
  {
    return "https://d3436qb9f9xu23.cloudfront.net/replier/overlays/android/" + a() + paramString;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ij
 * JD-Core Version:    0.7.0.1
 */