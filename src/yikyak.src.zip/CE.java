 enum CE
{
  CE()
  {
    super(str, i, null);
  }
  
  public String toString()
  {
    return "updateSince";
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CE
 * JD-Core Version:    0.7.0.1
 */