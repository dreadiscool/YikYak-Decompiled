import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class Ca
{
  public static void a(ContentValues paramContentValues)
  {
    BZ.a().getWritableDatabase().insert(Cc.class.getSimpleName(), null, paramContentValues);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ca
 * JD-Core Version:    0.7.0.1
 */