import java.io.File;
import java.util.concurrent.Callable;

class I
  implements Callable<Void>
{
  I(G paramG) {}
  
  public Void a()
  {
    G.a(this.a).createNewFile();
    IC.g();
    return null;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     I
 * JD-Core Version:    0.7.0.1
 */