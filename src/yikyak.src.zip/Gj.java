class Gj
  implements Runnable
{
  Gj(Gh paramGh) {}
  
  public void run()
  {
    if (Gd.i(this.a.c) == Gn.c) {
      this.a.c.a(Gn.b, false);
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Gj
 * JD-Core Version:    0.7.0.1
 */