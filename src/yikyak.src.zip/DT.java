import com.yik.yak.ui.activity.SendAYak;

public class DT
  implements Cj
{
  public DT(SendAYak paramSendAYak) {}
  
  public void a(zF paramzF, Object paramObject)
  {
    CJ[] arrayOfCJ = (CJ[])paramObject;
    BZ.a().a(Cd.class.getSimpleName());
    Cb.a(arrayOfCJ);
  }
  
  public void a(zz paramzz, Exception paramException) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DT
 * JD-Core Version:    0.7.0.1
 */