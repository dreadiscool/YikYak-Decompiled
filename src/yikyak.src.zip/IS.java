import android.content.Context;

public abstract interface IS<T>
{
  public abstract T a(Context paramContext, IT<T> paramIT);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IS
 * JD-Core Version:    0.7.0.1
 */