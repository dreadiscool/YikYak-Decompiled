import android.graphics.drawable.Drawable;

public class Ct
{
  private String a;
  private Drawable b;
  private int c;
  
  public Ct(Drawable paramDrawable, String paramString, int paramInt)
  {
    this.b = paramDrawable;
    this.a = paramString;
    this.c = paramInt;
  }
  
  public String a()
  {
    return this.a;
  }
  
  public Drawable b()
  {
    return this.b;
  }
  
  public int c()
  {
    return this.c;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ct
 * JD-Core Version:    0.7.0.1
 */