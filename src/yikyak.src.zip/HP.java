public final class HP
{
  private static HQ a = new HR();
  
  public static HQ a()
  {
    return a;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     HP
 * JD-Core Version:    0.7.0.1
 */