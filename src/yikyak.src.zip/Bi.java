class Bi
  extends LH
{
  Bi(Bh paramBh, LV paramLV)
  {
    super(paramLV);
  }
  
  public long a(Lz paramLz, long paramLong)
  {
    long l1 = -1L;
    if (Bh.a(this.a) == 0) {}
    for (;;)
    {
      return l1;
      long l2 = super.a(paramLz, Math.min(paramLong, Bh.a(this.a)));
      if (l2 != l1)
      {
        Bh.a(this.a, (int)(Bh.a(this.a) - l2));
        l1 = l2;
      }
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bi
 * JD-Core Version:    0.7.0.1
 */