import java.io.IOException;

class Bt
  extends zU
{
  Bt(Br paramBr, String paramString, Object[] paramArrayOfObject, int paramInt, long paramVarArgs)
  {
    super(paramString, paramArrayOfObject);
  }
  
  public void b()
  {
    try
    {
      this.d.i.a(this.a, this.c);
      label20:
      return;
    }
    catch (IOException localIOException)
    {
      break label20;
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bt
 * JD-Core Version:    0.7.0.1
 */