import java.util.concurrent.Callable;

public abstract class JW<V>
  extends JZ
  implements Callable<V>
{}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     JW
 * JD-Core Version:    0.7.0.1
 */