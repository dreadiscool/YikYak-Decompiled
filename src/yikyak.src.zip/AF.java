public final class AF
  extends zI
{
  private final zo a;
  private final LD b;
  
  public AF(zo paramzo, LD paramLD)
  {
    this.a = paramzo;
    this.b = paramLD;
  }
  
  public zt a()
  {
    String str = this.a.a("Content-Type");
    if (str != null) {}
    for (zt localzt = zt.a(str);; localzt = null) {
      return localzt;
    }
  }
  
  public long b()
  {
    return AD.a(this.a);
  }
  
  public LD c()
  {
    return this.b;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     AF
 * JD-Core Version:    0.7.0.1
 */