import com.yik.yak.ui.activity.MainActivity;

public class Dj
  implements Runnable
{
  public Dj(MainActivity paramMainActivity) {}
  
  public void run()
  {
    MainActivity.a(this.a, true);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dj
 * JD-Core Version:    0.7.0.1
 */