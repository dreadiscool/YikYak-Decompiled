class Cg
  implements Runnable
{
  Cg(Cf paramCf, zF paramzF, Object paramObject) {}
  
  public void run()
  {
    this.c.c.a(this.a, this.b);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cg
 * JD-Core Version:    0.7.0.1
 */