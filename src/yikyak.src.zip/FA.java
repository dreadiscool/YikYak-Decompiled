import com.yik.yak.ui.fragment.CommentFragment;

public class FA
  implements Hb
{
  public FA(CommentFragment paramCommentFragment) {}
  
  public void a()
  {
    this.a.a();
    If.a().l();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FA
 * JD-Core Version:    0.7.0.1
 */