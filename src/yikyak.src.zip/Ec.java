import com.yik.yak.ui.activity.SendAYak;
import java.io.IOException;

class Ec
  implements Runnable
{
  Ec(Ea paramEa, IOException paramIOException) {}
  
  public void run()
  {
    SendAYak.a(this.b.c, false);
    new StringBuilder().append(this.a.getMessage()).append("").toString();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ec
 * JD-Core Version:    0.7.0.1
 */