import java.net.Proxy;

public abstract interface yK
{
  public abstract zz a(Proxy paramProxy, zF paramzF);
  
  public abstract zz b(Proxy paramProxy, zF paramzF);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     yK
 * JD-Core Version:    0.7.0.1
 */