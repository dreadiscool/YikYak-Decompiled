import android.view.MotionEvent;

public abstract interface HL
{
  public abstract void a(HS paramHS);
  
  public abstract boolean a();
  
  public abstract boolean c(MotionEvent paramMotionEvent);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     HL
 * JD-Core Version:    0.7.0.1
 */