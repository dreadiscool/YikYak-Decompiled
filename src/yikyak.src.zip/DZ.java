import com.yik.yak.ui.activity.SendAYak;
import java.io.IOException;

class DZ
  implements Runnable
{
  DZ(DX paramDX, IOException paramIOException) {}
  
  public void run()
  {
    SendAYak.a(this.b.b, false);
    new StringBuilder().append(this.a.getMessage()).append("").toString();
    this.b.b.setResult(2003);
    this.b.b.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DZ
 * JD-Core Version:    0.7.0.1
 */