import android.view.View;
import android.view.View.OnClickListener;

class FP
  implements View.OnClickListener
{
  FP(FH paramFH) {}
  
  public void onClick(View paramView)
  {
    FH.g(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FP
 * JD-Core Version:    0.7.0.1
 */