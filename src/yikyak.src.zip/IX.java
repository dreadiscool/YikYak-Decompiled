class IX
  extends Jf
{
  IX(IW paramIW, IV paramIV) {}
  
  public void a()
  {
    IV localIV = IW.a(this.b);
    if (!this.a.equals(localIV))
    {
      IC.g();
      IW.a(this.b, localIV);
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IX
 * JD-Core Version:    0.7.0.1
 */