import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.yik.yak.ui.activity.MainActivity;

public class Di
  extends BroadcastReceiver
{
  public Di(MainActivity paramMainActivity) {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    this.a.f();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Di
 * JD-Core Version:    0.7.0.1
 */