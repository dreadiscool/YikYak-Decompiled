import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.SendAYak;

public class DP
  implements View.OnClickListener
{
  public DP(SendAYak paramSendAYak) {}
  
  public void onClick(View paramView)
  {
    SendAYak.p(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DP
 * JD-Core Version:    0.7.0.1
 */