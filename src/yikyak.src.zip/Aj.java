public final class Aj
{
  public final zz a;
  public final zF b;
  
  private Aj(zz paramzz, zF paramzF)
  {
    this.a = paramzz;
    this.b = paramzF;
  }
  
  public static boolean a(zF paramzF, zz paramzz)
  {
    boolean bool = false;
    switch (paramzF.c())
    {
    }
    for (;;)
    {
      return bool;
      if (((paramzF.a("Expires") != null) || (paramzF.m().c() != -1) || (paramzF.m().d() != -1) || (paramzF.m().e())) && (!paramzF.m().b()) && (!paramzz.h().b())) {
        bool = true;
      }
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Aj
 * JD-Core Version:    0.7.0.1
 */