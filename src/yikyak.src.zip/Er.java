import com.yik.yak.ui.activity.SplashScreen;

public class Er
  implements Runnable
{
  public Er(SplashScreen paramSplashScreen) {}
  
  public void run()
  {
    SplashScreen.g(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Er
 * JD-Core Version:    0.7.0.1
 */