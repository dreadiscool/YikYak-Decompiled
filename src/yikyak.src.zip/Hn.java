public class Hn
{
  public String a;
  public int b;
  public int c;
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hn
 * JD-Core Version:    0.7.0.1
 */