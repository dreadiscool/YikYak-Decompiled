import java.io.IOException;

class Bs
  extends zU
{
  Bs(Br paramBr, String paramString, Object[] paramArrayOfObject, int paramInt, AP paramVarArgs)
  {
    super(paramString, paramArrayOfObject);
  }
  
  public void b()
  {
    try
    {
      this.d.b(this.a, this.c);
      label15:
      return;
    }
    catch (IOException localIOException)
    {
      break label15;
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bs
 * JD-Core Version:    0.7.0.1
 */