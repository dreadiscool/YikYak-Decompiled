 enum CF
{
  CF()
  {
    super(str, i, null);
  }
  
  public String toString()
  {
    return "updateBatch";
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CF
 * JD-Core Version:    0.7.0.1
 */