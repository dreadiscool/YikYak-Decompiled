public abstract interface Ai
{
  public abstract void a();
  
  public abstract LU b();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ai
 * JD-Core Version:    0.7.0.1
 */