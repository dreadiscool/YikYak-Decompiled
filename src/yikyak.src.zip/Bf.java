public abstract interface Bf
{
  public static final Bf a = new Bg();
  
  public abstract void a(BD paramBD);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bf
 * JD-Core Version:    0.7.0.1
 */