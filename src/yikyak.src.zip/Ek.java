import com.yik.yak.ui.activity.SplashScreen;

public class Ek
  implements Runnable
{
  public Ek(SplashScreen paramSplashScreen) {}
  
  public void run()
  {
    SplashScreen.c(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ek
 * JD-Core Version:    0.7.0.1
 */