import android.view.View;
import android.view.View.OnClickListener;

class FC
  implements View.OnClickListener
{
  FC(FB paramFB) {}
  
  public void onClick(View paramView) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FC
 * JD-Core Version:    0.7.0.1
 */