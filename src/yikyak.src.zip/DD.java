import com.yik.yak.ui.activity.PinCodeDialog;

public class DD
  implements Runnable
{
  public DD(PinCodeDialog paramPinCodeDialog) {}
  
  public void run()
  {
    this.a.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DD
 * JD-Core Version:    0.7.0.1
 */