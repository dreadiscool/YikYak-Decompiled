import android.view.View;
import android.view.View.OnClickListener;

class EM
  implements View.OnClickListener
{
  EM(EL paramEL, CJ paramCJ) {}
  
  public void onClick(View paramView)
  {
    EI.a(this.b.a, this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     EM
 * JD-Core Version:    0.7.0.1
 */