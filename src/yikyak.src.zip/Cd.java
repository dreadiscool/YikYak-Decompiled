public class Cd
  extends BO
{
  protected void b()
  {
    a(new BL("display", BN.a, new BM[0]));
    a(new BL("category", BN.e, new BM[0]));
    a(new BL("name", BN.e, new BM[0]));
    a(new BL("url", BN.e, new BM[0]));
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cd
 * JD-Core Version:    0.7.0.1
 */