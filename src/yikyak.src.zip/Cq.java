public class Cq
  extends Ck
{
  @pp(a="yt")
  private String a;
  
  public Cq(String paramString)
  {
    this.a = paramString;
  }
  
  public String b()
  {
    return "http://ec2-54-173-31-102.compute-1.amazonaws.com/validateUrl";
  }
  
  public Cp e()
  {
    return Cp.b;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cq
 * JD-Core Version:    0.7.0.1
 */