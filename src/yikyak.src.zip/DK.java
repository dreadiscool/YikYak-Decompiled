import com.yik.yak.ui.activity.ReportDialog;

public class DK
  implements Runnable
{
  public DK(ReportDialog paramReportDialog) {}
  
  public void run()
  {
    this.a.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DK
 * JD-Core Version:    0.7.0.1
 */