import android.content.Context;

public abstract class Ck
  implements Cr
{
  public Class<?> a()
  {
    return null;
  }
  
  public void a(Context paramContext, Cj paramCj)
  {
    Ce.a().a(paramContext, this, paramCj);
  }
  
  public String b()
  {
    return c() + d();
  }
  
  protected String c()
  {
    return null;
  }
  
  protected String d()
  {
    return null;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ck
 * JD-Core Version:    0.7.0.1
 */