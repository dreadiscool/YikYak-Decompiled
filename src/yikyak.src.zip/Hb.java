public abstract interface Hb
{
  public abstract void a();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hb
 * JD-Core Version:    0.7.0.1
 */