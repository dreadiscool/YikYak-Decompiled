import java.util.List;

public abstract interface AR
{
  public abstract void a(int paramInt1, int paramInt2, List<AT> paramList);
  
  public abstract void a(int paramInt, long paramLong);
  
  public abstract void a(int paramInt, AP paramAP);
  
  public abstract void a(int paramInt, AP paramAP, LE paramLE);
  
  public abstract void a(boolean paramBoolean, int paramInt1, int paramInt2);
  
  public abstract void a(boolean paramBoolean, int paramInt1, LD paramLD, int paramInt2);
  
  public abstract void a(boolean paramBoolean, Bn paramBn);
  
  public abstract void a(boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, List<AT> paramList, AU paramAU);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     AR
 * JD-Core Version:    0.7.0.1
 */