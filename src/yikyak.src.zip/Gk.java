import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import java.io.IOException;

class Gk
  implements yZ
{
  Handler a = new Handler(this.b.getActivity().getMainLooper());
  
  Gk(Gd paramGd) {}
  
  public void a(zF paramzF)
  {
    this.a.post(new Gl(this));
  }
  
  public void a(zz paramzz, IOException paramIOException) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Gk
 * JD-Core Version:    0.7.0.1
 */