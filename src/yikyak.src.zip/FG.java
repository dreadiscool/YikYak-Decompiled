import android.widget.TextView;

class FG
  implements Runnable
{
  FG(FF paramFF, TextView paramTextView) {}
  
  public void run()
  {
    this.a.setSingleLine(false);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FG
 * JD-Core Version:    0.7.0.1
 */