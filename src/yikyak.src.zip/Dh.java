import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.FamousActivity;

public class Dh
  implements View.OnClickListener
{
  public Dh(FamousActivity paramFamousActivity) {}
  
  public void onClick(View paramView)
  {
    FamousActivity.a(this.a, FamousActivity.a(this.a), FamousActivity.b(this.a), false);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dh
 * JD-Core Version:    0.7.0.1
 */