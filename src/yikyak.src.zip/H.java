class H
  extends JW<Void>
{
  H(G paramG) {}
  
  public Void a()
  {
    return this.a.b();
  }
  
  public JS b()
  {
    return JS.d;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     H
 * JD-Core Version:    0.7.0.1
 */