public enum Fn
{
  static
  {
    Fn[] arrayOfFn = new Fn[2];
    arrayOfFn[0] = a;
    arrayOfFn[1] = b;
    c = arrayOfFn;
  }
  
  private Fn() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fn
 * JD-Core Version:    0.7.0.1
 */