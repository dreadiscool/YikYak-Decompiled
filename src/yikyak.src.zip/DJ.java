import com.yik.yak.ui.activity.ReportDialog;

class DJ
  implements Runnable
{
  DJ(DI paramDI) {}
  
  public void run()
  {
    this.a.a.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DJ
 * JD-Core Version:    0.7.0.1
 */