import com.yik.yak.ui.view.PhotoLinkCardView;

public abstract interface Hs
{
  public abstract void onLinkCardClicked(PhotoLinkCardView paramPhotoLinkCardView);
  
  public abstract void onPhotoCardClicked(PhotoLinkCardView paramPhotoLinkCardView);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hs
 * JD-Core Version:    0.7.0.1
 */