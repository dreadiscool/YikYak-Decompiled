import com.nispok.snackbar.Snackbar;

public abstract interface yE
{
  public abstract void a(Snackbar paramSnackbar);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     yE
 * JD-Core Version:    0.7.0.1
 */