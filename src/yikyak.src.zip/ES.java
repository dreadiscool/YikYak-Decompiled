import com.google.android.gms.maps.model.LatLng;
import com.yik.yak.ui.adapter.viewholder.YakDetailViewHolder;

public class ES
  implements jI
{
  public ES(YakDetailViewHolder paramYakDetailViewHolder) {}
  
  public void a(LatLng paramLatLng)
  {
    YakDetailViewHolder.access$000(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     ES
 * JD-Core Version:    0.7.0.1
 */