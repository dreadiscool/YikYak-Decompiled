import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class Ff
  extends BroadcastReceiver
{
  Ff(Fb paramFb) {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    this.a.e();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ff
 * JD-Core Version:    0.7.0.1
 */