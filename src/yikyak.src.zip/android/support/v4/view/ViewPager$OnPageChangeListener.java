package android.support.v4.view;

public abstract interface ViewPager$OnPageChangeListener
{
  public abstract void onPageScrollStateChanged(int paramInt);
  
  public abstract void onPageScrolled(int paramInt1, float paramFloat, int paramInt2);
  
  public abstract void onPageSelected(int paramInt);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPager.OnPageChangeListener
 * JD-Core Version:    0.7.0.1
 */