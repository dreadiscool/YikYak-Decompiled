package android.support.v4.app;

public abstract interface FragmentManager$OnBackStackChangedListener
{
  public abstract void onBackStackChanged();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManager.OnBackStackChangedListener
 * JD-Core Version:    0.7.0.1
 */