package android.support.v7.widget;

public abstract class RecyclerView$OnScrollListener
{
  public void onScrollStateChanged(RecyclerView paramRecyclerView, int paramInt) {}
  
  public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.RecyclerView.OnScrollListener
 * JD-Core Version:    0.7.0.1
 */