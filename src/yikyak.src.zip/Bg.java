final class Bg
  implements Bf
{
  public void a(BD paramBD)
  {
    paramBD.a(AP.k);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bg
 * JD-Core Version:    0.7.0.1
 */