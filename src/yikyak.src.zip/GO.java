import android.view.View;
import android.view.View.OnClickListener;

class GO
  implements View.OnClickListener
{
  GO(GI paramGI) {}
  
  public void onClick(View paramView) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     GO
 * JD-Core Version:    0.7.0.1
 */