public abstract interface BI
{
  public abstract AQ a(LD paramLD, boolean paramBoolean);
  
  public abstract AS a(LC paramLC, boolean paramBoolean);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     BI
 * JD-Core Version:    0.7.0.1
 */