import java.io.IOException;

public abstract interface yZ
{
  public abstract void a(zF paramzF);
  
  public abstract void a(zz paramzz, IOException paramIOException);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     yZ
 * JD-Core Version:    0.7.0.1
 */