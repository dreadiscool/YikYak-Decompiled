public enum BN
{
  static
  {
    BN[] arrayOfBN = new BN[5];
    arrayOfBN[0] = a;
    arrayOfBN[1] = b;
    arrayOfBN[2] = c;
    arrayOfBN[3] = d;
    arrayOfBN[4] = e;
    f = arrayOfBN;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     BN
 * JD-Core Version:    0.7.0.1
 */