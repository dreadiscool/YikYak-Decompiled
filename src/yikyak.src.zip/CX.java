public enum CX
{
  static
  {
    CX[] arrayOfCX = new CX[4];
    arrayOfCX[0] = a;
    arrayOfCX[1] = b;
    arrayOfCX[2] = c;
    arrayOfCX[3] = d;
    e = arrayOfCX;
  }
  
  private CX() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CX
 * JD-Core Version:    0.7.0.1
 */