import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.yik.yak.ui.fragment.CommentFragment;
import com.yik.yak.ui.fragment.CommentFragment..ViewInjector;

public class Fo
  extends DebouncingOnClickListener
{
  public Fo(CommentFragment..ViewInjector paramViewInjector, CommentFragment paramCommentFragment) {}
  
  public void doClick(View paramView)
  {
    this.a.onSendCommentClicked();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fo
 * JD-Core Version:    0.7.0.1
 */