import java.io.IOException;

class CL
  implements yZ
{
  CL(CK paramCK) {}
  
  public void a(zF paramzF) {}
  
  public void a(zz paramzz, IOException paramIOException) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CL
 * JD-Core Version:    0.7.0.1
 */