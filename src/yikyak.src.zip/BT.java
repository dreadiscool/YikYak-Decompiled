public final class BT
{
  public static final int abc_max_action_buttons = 2131623936;
  public static final int card_flip_time_full = 2131623937;
  public static final int card_flip_time_half = 2131623938;
  public static final int google_play_services_version = 2131623939;
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     BT
 * JD-Core Version:    0.7.0.1
 */