import java.io.Closeable;

public abstract interface LU
  extends Closeable
{
  public abstract void a();
  
  public abstract void a_(Lz paramLz, long paramLong);
  
  public abstract LW b();
  
  public abstract void close();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     LU
 * JD-Core Version:    0.7.0.1
 */