import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.DraftDialog;

public class Df
  implements View.OnClickListener
{
  public Df(DraftDialog paramDraftDialog) {}
  
  public void onClick(View paramView)
  {
    this.a.setResult(2);
    DraftDialog.a(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Df
 * JD-Core Version:    0.7.0.1
 */