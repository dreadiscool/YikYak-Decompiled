public class Cs
{
  public boolean a = false;
  public double b;
  public double c;
  public double d;
  public double e;
  public String f;
  
  public Cs(boolean paramBoolean, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, String paramString)
  {
    this.a = paramBoolean;
    this.b = paramDouble1;
    this.c = paramDouble2;
    this.d = paramDouble3;
    this.e = paramDouble4;
    this.f = paramString;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cs
 * JD-Core Version:    0.7.0.1
 */