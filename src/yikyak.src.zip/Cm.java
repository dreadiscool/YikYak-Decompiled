import android.content.Context;
import android.content.res.Resources;
import com.yik.yak.YikYak;

public class Cm
  extends Ck
{
  public String b()
  {
    return YikYak.d().getResources().getString(2131230888);
  }
  
  public Cp e()
  {
    return Cp.a;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cm
 * JD-Core Version:    0.7.0.1
 */