import java.net.Socket;

public class Bz
{
  private String a;
  private Socket b;
  private Bf c = Bf.a;
  private zy d = zy.c;
  private Bl e = Bl.a;
  private boolean f;
  
  public Bz(String paramString, boolean paramBoolean, Socket paramSocket)
  {
    this.a = paramString;
    this.f = paramBoolean;
    this.b = paramSocket;
  }
  
  public Br a()
  {
    return new Br(this, null);
  }
  
  public Bz a(zy paramzy)
  {
    this.d = paramzy;
    return this;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bz
 * JD-Core Version:    0.7.0.1
 */