public abstract interface JY<T>
  extends Comparable<T>
{
  public abstract JS b();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     JY
 * JD-Core Version:    0.7.0.1
 */