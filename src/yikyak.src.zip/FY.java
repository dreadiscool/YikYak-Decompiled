import android.view.View;
import android.view.View.OnClickListener;

class FY
  implements View.OnClickListener
{
  FY(FV paramFV) {}
  
  public void onClick(View paramView)
  {
    FV.b(this.a, FV.c(this.a));
    FV.d(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FY
 * JD-Core Version:    0.7.0.1
 */