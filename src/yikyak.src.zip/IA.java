import android.app.Activity;
import android.os.Bundle;

public abstract class IA
{
  public void a(Activity paramActivity) {}
  
  public void a(Activity paramActivity, Bundle paramBundle) {}
  
  public void b(Activity paramActivity) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IA
 * JD-Core Version:    0.7.0.1
 */