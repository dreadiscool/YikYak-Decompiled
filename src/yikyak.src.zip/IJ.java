public class IJ
  implements IH<Object>
{
  public void a(Exception paramException) {}
  
  public void a(Object paramObject) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IJ
 * JD-Core Version:    0.7.0.1
 */