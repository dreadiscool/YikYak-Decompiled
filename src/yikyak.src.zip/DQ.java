import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.SendAYak;

public class DQ
  implements View.OnClickListener
{
  public DQ(SendAYak paramSendAYak) {}
  
  public void onClick(View paramView)
  {
    SendAYak.c(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DQ
 * JD-Core Version:    0.7.0.1
 */