public final class Ag
{
  public static String a()
  {
    return "okhttp/2.2.0";
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ag
 * JD-Core Version:    0.7.0.1
 */