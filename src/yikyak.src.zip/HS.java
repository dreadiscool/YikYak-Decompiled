public abstract interface HS
{
  public abstract void a(float paramFloat1, float paramFloat2);
  
  public abstract void a(float paramFloat1, float paramFloat2, float paramFloat3);
  
  public abstract void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     HS
 * JD-Core Version:    0.7.0.1
 */