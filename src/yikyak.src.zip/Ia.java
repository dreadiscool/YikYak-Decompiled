public abstract interface Ia {}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ia
 * JD-Core Version:    0.7.0.1
 */