import java.io.IOException;

class BC
  extends zU
{
  BC(BA paramBA, String paramString, Object[] paramArrayOfObject, Bn paramVarArgs)
  {
    super(paramString, paramArrayOfObject);
  }
  
  public void b()
  {
    try
    {
      this.c.c.i.a(this.a);
      label19:
      return;
    }
    catch (IOException localIOException)
    {
      break label19;
    }
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     BC
 * JD-Core Version:    0.7.0.1
 */