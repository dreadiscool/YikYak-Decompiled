import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.yik.yak.ui.adapter.viewholder.YakDetailViewHolder;
import com.yik.yak.ui.adapter.viewholder.YakDetailViewHolder..ViewInjector;

public class ER
  extends DebouncingOnClickListener
{
  public ER(YakDetailViewHolder..ViewInjector paramViewInjector, YakDetailViewHolder paramYakDetailViewHolder) {}
  
  public void doClick(View paramView)
  {
    this.a.onClick();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     ER
 * JD-Core Version:    0.7.0.1
 */