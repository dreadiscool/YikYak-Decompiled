public abstract interface zs
{
  public abstract zF a(zz paramzz);
  
  public abstract zz a();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     zs
 * JD-Core Version:    0.7.0.1
 */