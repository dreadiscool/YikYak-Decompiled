import java.io.IOException;

class F
  extends IOException
{
  F()
  {
    super("CodedOutputStream was writing to a flat byte array and ran out of space.");
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     F
 * JD-Core Version:    0.7.0.1
 */