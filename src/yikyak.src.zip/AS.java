import java.io.Closeable;
import java.util.List;

public abstract interface AS
  extends Closeable
{
  public abstract void a();
  
  public abstract void a(int paramInt1, int paramInt2, List<AT> paramList);
  
  public abstract void a(int paramInt, long paramLong);
  
  public abstract void a(int paramInt, AP paramAP);
  
  public abstract void a(int paramInt, AP paramAP, byte[] paramArrayOfByte);
  
  public abstract void a(Bn paramBn);
  
  public abstract void a(boolean paramBoolean, int paramInt1, int paramInt2);
  
  public abstract void a(boolean paramBoolean, int paramInt1, Lz paramLz, int paramInt2);
  
  public abstract void a(boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, List<AT> paramList);
  
  public abstract void b();
  
  public abstract void b(Bn paramBn);
  
  public abstract int c();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     AS
 * JD-Core Version:    0.7.0.1
 */