import com.yik.yak.ui.activity.YikYakDialog;

public class EB
  implements Runnable
{
  public EB(YikYakDialog paramYikYakDialog) {}
  
  public void run()
  {
    this.a.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     EB
 * JD-Core Version:    0.7.0.1
 */