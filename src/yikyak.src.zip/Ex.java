import android.view.View;
import android.view.View.OnClickListener;
import com.yik.yak.ui.activity.YakarmaActivity;

public class Ex
  implements View.OnClickListener
{
  public Ex(YakarmaActivity paramYakarmaActivity) {}
  
  public void onClick(View paramView)
  {
    Iw.a(this.a, 2131231012, 2131231013);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ex
 * JD-Core Version:    0.7.0.1
 */