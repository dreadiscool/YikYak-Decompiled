import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.LinearLayout;

class Fc
  implements Animation.AnimationListener
{
  Fc(Fb paramFb) {}
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    this.a.C.setVisibility(8);
    this.a.E.findViewById(2131558746).setVisibility(8);
    this.a.E.findViewById(2131558743).setVisibility(8);
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fc
 * JD-Core Version:    0.7.0.1
 */