import android.widget.EditText;
import com.yik.yak.ui.fragment.CommentFragment;

class Fq
  implements Runnable
{
  Fq(Fp paramFp) {}
  
  public void run()
  {
    If.a().b(this.a.c.k);
    this.a.c.mReplyField.setText("");
    this.a.c.g = false;
    this.a.c.a(true);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fq
 * JD-Core Version:    0.7.0.1
 */