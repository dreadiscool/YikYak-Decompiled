import java.io.Closeable;

public abstract interface AQ
  extends Closeable
{
  public abstract void a();
  
  public abstract boolean a(AR paramAR);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     AQ
 * JD-Core Version:    0.7.0.1
 */