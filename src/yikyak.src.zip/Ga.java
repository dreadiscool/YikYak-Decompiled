import android.view.View;
import android.view.View.OnClickListener;

class Ga
  implements View.OnClickListener
{
  Ga(FV paramFV) {}
  
  public void onClick(View paramView)
  {
    FV.d(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ga
 * JD-Core Version:    0.7.0.1
 */