package com.adjust.sdk;

public abstract interface OnFinishedListener
{
  public abstract void onFinishedTracking(ResponseData paramResponseData);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     com.adjust.sdk.OnFinishedListener
 * JD-Core Version:    0.7.0.1
 */