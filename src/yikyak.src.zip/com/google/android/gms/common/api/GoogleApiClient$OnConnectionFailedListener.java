package com.google.android.gms.common.api;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;

public abstract interface GoogleApiClient$OnConnectionFailedListener
  extends GooglePlayServicesClient.OnConnectionFailedListener
{
  public abstract void onConnectionFailed(ConnectionResult paramConnectionResult);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener
 * JD-Core Version:    0.7.0.1
 */