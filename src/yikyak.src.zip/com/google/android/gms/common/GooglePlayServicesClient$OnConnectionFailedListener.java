package com.google.android.gms.common;

@Deprecated
public abstract interface GooglePlayServicesClient$OnConnectionFailedListener
{
  public abstract void onConnectionFailed(ConnectionResult paramConnectionResult);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener
 * JD-Core Version:    0.7.0.1
 */