package com.squareup.picasso;

public abstract interface Callback
{
  public abstract void onError();
  
  public abstract void onSuccess();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     com.squareup.picasso.Callback
 * JD-Core Version:    0.7.0.1
 */