import java.util.Comparator;

class Fh
  implements Comparator<CK>
{
  Fh(Fb paramFb) {}
  
  public int a(CK paramCK1, CK paramCK2)
  {
    return paramCK2.d - paramCK1.d;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Fh
 * JD-Core Version:    0.7.0.1
 */