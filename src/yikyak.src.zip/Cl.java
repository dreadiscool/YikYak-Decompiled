import android.content.Context;
import android.content.res.Resources;
import com.yik.yak.YikYak;

public class Cl
  extends Ck
{
  public String b()
  {
    return YikYak.d().getResources().getString(2131230885);
  }
  
  public Cp e()
  {
    return Cp.a;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cl
 * JD-Core Version:    0.7.0.1
 */