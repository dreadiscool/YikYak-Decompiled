import com.yik.yak.ui.activity.SplashScreen;

public class El
  implements Runnable
{
  public El(SplashScreen paramSplashScreen) {}
  
  public void run()
  {
    SplashScreen.a(this.a, true);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     El
 * JD-Core Version:    0.7.0.1
 */