import com.squareup.picasso.Callback;
import com.yik.yak.ui.activity.PhotoActivity;

public class Dz
  implements Callback
{
  public Dz(PhotoActivity paramPhotoActivity) {}
  
  public void onError() {}
  
  public void onSuccess()
  {
    this.a.b = new HT(this.a.mImageView);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dz
 * JD-Core Version:    0.7.0.1
 */