public enum CI
{
  static
  {
    CI[] arrayOfCI = new CI[2];
    arrayOfCI[0] = a;
    arrayOfCI[1] = b;
    c = arrayOfCI;
  }
  
  private CI() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     CI
 * JD-Core Version:    0.7.0.1
 */