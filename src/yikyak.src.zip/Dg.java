import com.yik.yak.ui.activity.DraftDialog;

public class Dg
  implements Runnable
{
  public Dg(DraftDialog paramDraftDialog) {}
  
  public void run()
  {
    this.a.finish();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Dg
 * JD-Core Version:    0.7.0.1
 */