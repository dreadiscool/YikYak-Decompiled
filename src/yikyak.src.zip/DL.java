import com.yik.yak.ui.activity.SendAYak;

public class DL
  implements Runnable
{
  public DL(SendAYak paramSendAYak) {}
  
  public void run()
  {
    SendAYak.a(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     DL
 * JD-Core Version:    0.7.0.1
 */