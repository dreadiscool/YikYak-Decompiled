import android.content.Context;

public abstract interface IT<T>
{
  public abstract T c(Context paramContext);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IT
 * JD-Core Version:    0.7.0.1
 */