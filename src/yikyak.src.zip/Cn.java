import android.content.Context;
import android.content.res.Resources;
import com.yik.yak.YikYak;

public class Cn
  extends Ck
{
  public String b()
  {
    return CR.a("threatwords", "threatWordsUrl", YikYak.d().getResources().getString(2131230887));
  }
  
  public Cp e()
  {
    return Cp.a;
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Cn
 * JD-Core Version:    0.7.0.1
 */