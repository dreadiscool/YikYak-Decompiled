public abstract interface Ht
{
  public abstract int a();
  
  public abstract int a(int paramInt1, int paramInt2);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ht
 * JD-Core Version:    0.7.0.1
 */