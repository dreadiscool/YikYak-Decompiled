import com.yik.yak.ui.activity.SendAYak;
import java.io.IOException;

class Ee
  implements Runnable
{
  Ee(Ed paramEd, IOException paramIOException) {}
  
  public void run()
  {
    SendAYak.h(this.b.c);
    this.a.printStackTrace();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ee
 * JD-Core Version:    0.7.0.1
 */