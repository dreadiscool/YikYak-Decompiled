import android.view.View;
import android.view.View.OnClickListener;

class FO
  implements View.OnClickListener
{
  FO(FH paramFH) {}
  
  public void onClick(View paramView)
  {
    FH.a(this.a, FH.h(this.a), true);
    FH.g(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FO
 * JD-Core Version:    0.7.0.1
 */