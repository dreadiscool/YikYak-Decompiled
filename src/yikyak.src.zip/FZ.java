import android.view.View;
import android.view.View.OnClickListener;

class FZ
  implements View.OnClickListener
{
  FZ(FV paramFV) {}
  
  public void onClick(View paramView)
  {
    this.a.b(FV.c(this.a).i, FV.c(this.a).b);
    FV.d(this.a);
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     FZ
 * JD-Core Version:    0.7.0.1
 */