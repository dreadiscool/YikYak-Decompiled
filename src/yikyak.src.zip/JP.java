import java.util.Collection;

public abstract interface JP<T>
{
  public abstract Collection<T> c();
  
  public abstract void c(T paramT);
  
  public abstract boolean d();
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     JP
 * JD-Core Version:    0.7.0.1
 */