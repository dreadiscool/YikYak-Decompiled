public abstract interface IO
{
  public abstract void a(int paramInt, String paramString1, String paramString2);
  
  public abstract void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean);
  
  public abstract boolean a(String paramString, int paramInt);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     IO
 * JD-Core Version:    0.7.0.1
 */