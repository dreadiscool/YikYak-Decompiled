public enum Ih
{
  static
  {
    Ih[] arrayOfIh = new Ih[2];
    arrayOfIh[0] = a;
    arrayOfIh[1] = b;
    c = arrayOfIh;
  }
  
  private Ih() {}
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Ih
 * JD-Core Version:    0.7.0.1
 */