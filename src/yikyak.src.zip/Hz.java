public abstract interface Hz
{
  public abstract void a(Hx paramHx, long paramLong);
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Hz
 * JD-Core Version:    0.7.0.1
 */