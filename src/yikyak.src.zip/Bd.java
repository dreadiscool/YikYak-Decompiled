import java.io.ByteArrayOutputStream;

class Bd
{
  private static final int[] a;
  private static final byte[] b;
  private static final Bd c = new Bd();
  private final Be d = new Be();
  
  static
  {
    int[] arrayOfInt = new int[256];
    arrayOfInt[0] = 8184;
    arrayOfInt[1] = 8388568;
    arrayOfInt[2] = 268435426;
    arrayOfInt[3] = 268435427;
    arrayOfInt[4] = 268435428;
    arrayOfInt[5] = 268435429;
    arrayOfInt[6] = 268435430;
    arrayOfInt[7] = 268435431;
    arrayOfInt[8] = 268435432;
    arrayOfInt[9] = 16777194;
    arrayOfInt[10] = 1073741820;
    arrayOfInt[11] = 268435433;
    arrayOfInt[12] = 268435434;
    arrayOfInt[13] = 1073741821;
    arrayOfInt[14] = 268435435;
    arrayOfInt[15] = 268435436;
    arrayOfInt[16] = 268435437;
    arrayOfInt[17] = 268435438;
    arrayOfInt[18] = 268435439;
    arrayOfInt[19] = 268435440;
    arrayOfInt[20] = 268435441;
    arrayOfInt[21] = 268435442;
    arrayOfInt[22] = 1073741822;
    arrayOfInt[23] = 268435443;
    arrayOfInt[24] = 268435444;
    arrayOfInt[25] = 268435445;
    arrayOfInt[26] = 268435446;
    arrayOfInt[27] = 268435447;
    arrayOfInt[28] = 268435448;
    arrayOfInt[29] = 268435449;
    arrayOfInt[30] = 268435450;
    arrayOfInt[31] = 268435451;
    arrayOfInt[32] = 20;
    arrayOfInt[33] = 1016;
    arrayOfInt[34] = 1017;
    arrayOfInt[35] = 4090;
    arrayOfInt[36] = 8185;
    arrayOfInt[37] = 21;
    arrayOfInt[38] = 248;
    arrayOfInt[39] = 2042;
    arrayOfInt[40] = 1018;
    arrayOfInt[41] = 1019;
    arrayOfInt[42] = 249;
    arrayOfInt[43] = 2043;
    arrayOfInt[44] = 250;
    arrayOfInt[45] = 22;
    arrayOfInt[46] = 23;
    arrayOfInt[47] = 24;
    arrayOfInt[48] = 0;
    arrayOfInt[49] = 1;
    arrayOfInt[50] = 2;
    arrayOfInt[51] = 25;
    arrayOfInt[52] = 26;
    arrayOfInt[53] = 27;
    arrayOfInt[54] = 28;
    arrayOfInt[55] = 29;
    arrayOfInt[56] = 30;
    arrayOfInt[57] = 31;
    arrayOfInt[58] = 92;
    arrayOfInt[59] = 251;
    arrayOfInt[60] = 32764;
    arrayOfInt[61] = 32;
    arrayOfInt[62] = 4091;
    arrayOfInt[63] = 1020;
    arrayOfInt[64] = 8186;
    arrayOfInt[65] = 33;
    arrayOfInt[66] = 93;
    arrayOfInt[67] = 94;
    arrayOfInt[68] = 95;
    arrayOfInt[69] = 96;
    arrayOfInt[70] = 97;
    arrayOfInt[71] = 98;
    arrayOfInt[72] = 99;
    arrayOfInt[73] = 100;
    arrayOfInt[74] = 101;
    arrayOfInt[75] = 102;
    arrayOfInt[76] = 103;
    arrayOfInt[77] = 104;
    arrayOfInt[78] = 105;
    arrayOfInt[79] = 106;
    arrayOfInt[80] = 107;
    arrayOfInt[81] = 108;
    arrayOfInt[82] = 109;
    arrayOfInt[83] = 110;
    arrayOfInt[84] = 111;
    arrayOfInt[85] = 112;
    arrayOfInt[86] = 113;
    arrayOfInt[87] = 114;
    arrayOfInt[88] = 252;
    arrayOfInt[89] = 115;
    arrayOfInt[90] = 253;
    arrayOfInt[91] = 8187;
    arrayOfInt[92] = 524272;
    arrayOfInt[93] = 8188;
    arrayOfInt[94] = 16380;
    arrayOfInt[95] = 34;
    arrayOfInt[96] = 32765;
    arrayOfInt[97] = 3;
    arrayOfInt[98] = 35;
    arrayOfInt[99] = 4;
    arrayOfInt[100] = 36;
    arrayOfInt[101] = 5;
    arrayOfInt[102] = 37;
    arrayOfInt[103] = 38;
    arrayOfInt[104] = 39;
    arrayOfInt[105] = 6;
    arrayOfInt[106] = 116;
    arrayOfInt[107] = 117;
    arrayOfInt[108] = 40;
    arrayOfInt[109] = 41;
    arrayOfInt[110] = 42;
    arrayOfInt[111] = 7;
    arrayOfInt[112] = 43;
    arrayOfInt[113] = 118;
    arrayOfInt[114] = 44;
    arrayOfInt[115] = 8;
    arrayOfInt[116] = 9;
    arrayOfInt[117] = 45;
    arrayOfInt[118] = 119;
    arrayOfInt[119] = 120;
    arrayOfInt[120] = 121;
    arrayOfInt[121] = 122;
    arrayOfInt[122] = 123;
    arrayOfInt[123] = 32766;
    arrayOfInt[124] = 2044;
    arrayOfInt[125] = 16381;
    arrayOfInt[126] = 8189;
    arrayOfInt[127] = 268435452;
    arrayOfInt[''] = 1048550;
    arrayOfInt[''] = 4194258;
    arrayOfInt[''] = 1048551;
    arrayOfInt[''] = 1048552;
    arrayOfInt[''] = 4194259;
    arrayOfInt[''] = 4194260;
    arrayOfInt[''] = 4194261;
    arrayOfInt[''] = 8388569;
    arrayOfInt[''] = 4194262;
    arrayOfInt[''] = 8388570;
    arrayOfInt[''] = 8388571;
    arrayOfInt[''] = 8388572;
    arrayOfInt[''] = 8388573;
    arrayOfInt[''] = 8388574;
    arrayOfInt[''] = 16777195;
    arrayOfInt[''] = 8388575;
    arrayOfInt[''] = 16777196;
    arrayOfInt[''] = 16777197;
    arrayOfInt[''] = 4194263;
    arrayOfInt[''] = 8388576;
    arrayOfInt[''] = 16777198;
    arrayOfInt[''] = 8388577;
    arrayOfInt[''] = 8388578;
    arrayOfInt[''] = 8388579;
    arrayOfInt[''] = 8388580;
    arrayOfInt[''] = 2097116;
    arrayOfInt[''] = 4194264;
    arrayOfInt[''] = 8388581;
    arrayOfInt[''] = 4194265;
    arrayOfInt[''] = 8388582;
    arrayOfInt[''] = 8388583;
    arrayOfInt[''] = 16777199;
    arrayOfInt[' '] = 4194266;
    arrayOfInt['¡'] = 2097117;
    arrayOfInt['¢'] = 1048553;
    arrayOfInt['£'] = 4194267;
    arrayOfInt['¤'] = 4194268;
    arrayOfInt['¥'] = 8388584;
    arrayOfInt['¦'] = 8388585;
    arrayOfInt['§'] = 2097118;
    arrayOfInt['¨'] = 8388586;
    arrayOfInt['©'] = 4194269;
    arrayOfInt['ª'] = 4194270;
    arrayOfInt['«'] = 16777200;
    arrayOfInt['¬'] = 2097119;
    arrayOfInt['­'] = 4194271;
    arrayOfInt['®'] = 8388587;
    arrayOfInt['¯'] = 8388588;
    arrayOfInt['°'] = 2097120;
    arrayOfInt['±'] = 2097121;
    arrayOfInt['²'] = 4194272;
    arrayOfInt['³'] = 2097122;
    arrayOfInt['´'] = 8388589;
    arrayOfInt['µ'] = 4194273;
    arrayOfInt['¶'] = 8388590;
    arrayOfInt['·'] = 8388591;
    arrayOfInt['¸'] = 1048554;
    arrayOfInt['¹'] = 4194274;
    arrayOfInt['º'] = 4194275;
    arrayOfInt['»'] = 4194276;
    arrayOfInt['¼'] = 8388592;
    arrayOfInt['½'] = 4194277;
    arrayOfInt['¾'] = 4194278;
    arrayOfInt['¿'] = 8388593;
    arrayOfInt['À'] = 67108832;
    arrayOfInt['Á'] = 67108833;
    arrayOfInt['Â'] = 1048555;
    arrayOfInt['Ã'] = 524273;
    arrayOfInt['Ä'] = 4194279;
    arrayOfInt['Å'] = 8388594;
    arrayOfInt['Æ'] = 4194280;
    arrayOfInt['Ç'] = 33554412;
    arrayOfInt['È'] = 67108834;
    arrayOfInt['É'] = 67108835;
    arrayOfInt['Ê'] = 67108836;
    arrayOfInt['Ë'] = 134217694;
    arrayOfInt['Ì'] = 134217695;
    arrayOfInt['Í'] = 67108837;
    arrayOfInt['Î'] = 16777201;
    arrayOfInt['Ï'] = 33554413;
    arrayOfInt['Ð'] = 524274;
    arrayOfInt['Ñ'] = 2097123;
    arrayOfInt['Ò'] = 67108838;
    arrayOfInt['Ó'] = 134217696;
    arrayOfInt['Ô'] = 134217697;
    arrayOfInt['Õ'] = 67108839;
    arrayOfInt['Ö'] = 134217698;
    arrayOfInt['×'] = 16777202;
    arrayOfInt['Ø'] = 2097124;
    arrayOfInt['Ù'] = 2097125;
    arrayOfInt['Ú'] = 67108840;
    arrayOfInt['Û'] = 67108841;
    arrayOfInt['Ü'] = 268435453;
    arrayOfInt['Ý'] = 134217699;
    arrayOfInt['Þ'] = 134217700;
    arrayOfInt['ß'] = 134217701;
    arrayOfInt['à'] = 1048556;
    arrayOfInt['á'] = 16777203;
    arrayOfInt['â'] = 1048557;
    arrayOfInt['ã'] = 2097126;
    arrayOfInt['ä'] = 4194281;
    arrayOfInt['å'] = 2097127;
    arrayOfInt['æ'] = 2097128;
    arrayOfInt['ç'] = 8388595;
    arrayOfInt['è'] = 4194282;
    arrayOfInt['é'] = 4194283;
    arrayOfInt['ê'] = 33554414;
    arrayOfInt['ë'] = 33554415;
    arrayOfInt['ì'] = 16777204;
    arrayOfInt['í'] = 16777205;
    arrayOfInt['î'] = 67108842;
    arrayOfInt['ï'] = 8388596;
    arrayOfInt['ð'] = 67108843;
    arrayOfInt['ñ'] = 134217702;
    arrayOfInt['ò'] = 67108844;
    arrayOfInt['ó'] = 67108845;
    arrayOfInt['ô'] = 134217703;
    arrayOfInt['õ'] = 134217704;
    arrayOfInt['ö'] = 134217705;
    arrayOfInt['÷'] = 134217706;
    arrayOfInt['ø'] = 134217707;
    arrayOfInt['ù'] = 268435454;
    arrayOfInt['ú'] = 134217708;
    arrayOfInt['û'] = 134217709;
    arrayOfInt['ü'] = 134217710;
    arrayOfInt['ý'] = 134217711;
    arrayOfInt['þ'] = 134217712;
    arrayOfInt['ÿ'] = 67108846;
    a = arrayOfInt;
    byte[] arrayOfByte = new byte[256];
    arrayOfByte[0] = 13;
    arrayOfByte[1] = 23;
    arrayOfByte[2] = 28;
    arrayOfByte[3] = 28;
    arrayOfByte[4] = 28;
    arrayOfByte[5] = 28;
    arrayOfByte[6] = 28;
    arrayOfByte[7] = 28;
    arrayOfByte[8] = 28;
    arrayOfByte[9] = 24;
    arrayOfByte[10] = 30;
    arrayOfByte[11] = 28;
    arrayOfByte[12] = 28;
    arrayOfByte[13] = 30;
    arrayOfByte[14] = 28;
    arrayOfByte[15] = 28;
    arrayOfByte[16] = 28;
    arrayOfByte[17] = 28;
    arrayOfByte[18] = 28;
    arrayOfByte[19] = 28;
    arrayOfByte[20] = 28;
    arrayOfByte[21] = 28;
    arrayOfByte[22] = 30;
    arrayOfByte[23] = 28;
    arrayOfByte[24] = 28;
    arrayOfByte[25] = 28;
    arrayOfByte[26] = 28;
    arrayOfByte[27] = 28;
    arrayOfByte[28] = 28;
    arrayOfByte[29] = 28;
    arrayOfByte[30] = 28;
    arrayOfByte[31] = 28;
    arrayOfByte[32] = 6;
    arrayOfByte[33] = 10;
    arrayOfByte[34] = 10;
    arrayOfByte[35] = 12;
    arrayOfByte[36] = 13;
    arrayOfByte[37] = 6;
    arrayOfByte[38] = 8;
    arrayOfByte[39] = 11;
    arrayOfByte[40] = 10;
    arrayOfByte[41] = 10;
    arrayOfByte[42] = 8;
    arrayOfByte[43] = 11;
    arrayOfByte[44] = 8;
    arrayOfByte[45] = 6;
    arrayOfByte[46] = 6;
    arrayOfByte[47] = 6;
    arrayOfByte[48] = 5;
    arrayOfByte[49] = 5;
    arrayOfByte[50] = 5;
    arrayOfByte[51] = 6;
    arrayOfByte[52] = 6;
    arrayOfByte[53] = 6;
    arrayOfByte[54] = 6;
    arrayOfByte[55] = 6;
    arrayOfByte[56] = 6;
    arrayOfByte[57] = 6;
    arrayOfByte[58] = 7;
    arrayOfByte[59] = 8;
    arrayOfByte[60] = 15;
    arrayOfByte[61] = 6;
    arrayOfByte[62] = 12;
    arrayOfByte[63] = 10;
    arrayOfByte[64] = 13;
    arrayOfByte[65] = 6;
    arrayOfByte[66] = 7;
    arrayOfByte[67] = 7;
    arrayOfByte[68] = 7;
    arrayOfByte[69] = 7;
    arrayOfByte[70] = 7;
    arrayOfByte[71] = 7;
    arrayOfByte[72] = 7;
    arrayOfByte[73] = 7;
    arrayOfByte[74] = 7;
    arrayOfByte[75] = 7;
    arrayOfByte[76] = 7;
    arrayOfByte[77] = 7;
    arrayOfByte[78] = 7;
    arrayOfByte[79] = 7;
    arrayOfByte[80] = 7;
    arrayOfByte[81] = 7;
    arrayOfByte[82] = 7;
    arrayOfByte[83] = 7;
    arrayOfByte[84] = 7;
    arrayOfByte[85] = 7;
    arrayOfByte[86] = 7;
    arrayOfByte[87] = 7;
    arrayOfByte[88] = 8;
    arrayOfByte[89] = 7;
    arrayOfByte[90] = 8;
    arrayOfByte[91] = 13;
    arrayOfByte[92] = 19;
    arrayOfByte[93] = 13;
    arrayOfByte[94] = 14;
    arrayOfByte[95] = 6;
    arrayOfByte[96] = 15;
    arrayOfByte[97] = 5;
    arrayOfByte[98] = 6;
    arrayOfByte[99] = 5;
    arrayOfByte[100] = 6;
    arrayOfByte[101] = 5;
    arrayOfByte[102] = 6;
    arrayOfByte[103] = 6;
    arrayOfByte[104] = 6;
    arrayOfByte[105] = 5;
    arrayOfByte[106] = 7;
    arrayOfByte[107] = 7;
    arrayOfByte[108] = 6;
    arrayOfByte[109] = 6;
    arrayOfByte[110] = 6;
    arrayOfByte[111] = 5;
    arrayOfByte[112] = 6;
    arrayOfByte[113] = 7;
    arrayOfByte[114] = 6;
    arrayOfByte[115] = 5;
    arrayOfByte[116] = 5;
    arrayOfByte[117] = 6;
    arrayOfByte[118] = 7;
    arrayOfByte[119] = 7;
    arrayOfByte[120] = 7;
    arrayOfByte[121] = 7;
    arrayOfByte[122] = 7;
    arrayOfByte[123] = 15;
    arrayOfByte[124] = 11;
    arrayOfByte[125] = 14;
    arrayOfByte[126] = 13;
    arrayOfByte[127] = 28;
    arrayOfByte[''] = 20;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 20;
    arrayOfByte[''] = 20;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 24;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 24;
    arrayOfByte[''] = 24;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 24;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 21;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 22;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 23;
    arrayOfByte[''] = 24;
    arrayOfByte[' '] = 22;
    arrayOfByte['¡'] = 21;
    arrayOfByte['¢'] = 20;
    arrayOfByte['£'] = 22;
    arrayOfByte['¤'] = 22;
    arrayOfByte['¥'] = 23;
    arrayOfByte['¦'] = 23;
    arrayOfByte['§'] = 21;
    arrayOfByte['¨'] = 23;
    arrayOfByte['©'] = 22;
    arrayOfByte['ª'] = 22;
    arrayOfByte['«'] = 24;
    arrayOfByte['¬'] = 21;
    arrayOfByte['­'] = 22;
    arrayOfByte['®'] = 23;
    arrayOfByte['¯'] = 23;
    arrayOfByte['°'] = 21;
    arrayOfByte['±'] = 21;
    arrayOfByte['²'] = 22;
    arrayOfByte['³'] = 21;
    arrayOfByte['´'] = 23;
    arrayOfByte['µ'] = 22;
    arrayOfByte['¶'] = 23;
    arrayOfByte['·'] = 23;
    arrayOfByte['¸'] = 20;
    arrayOfByte['¹'] = 22;
    arrayOfByte['º'] = 22;
    arrayOfByte['»'] = 22;
    arrayOfByte['¼'] = 23;
    arrayOfByte['½'] = 22;
    arrayOfByte['¾'] = 22;
    arrayOfByte['¿'] = 23;
    arrayOfByte['À'] = 26;
    arrayOfByte['Á'] = 26;
    arrayOfByte['Â'] = 20;
    arrayOfByte['Ã'] = 19;
    arrayOfByte['Ä'] = 22;
    arrayOfByte['Å'] = 23;
    arrayOfByte['Æ'] = 22;
    arrayOfByte['Ç'] = 25;
    arrayOfByte['È'] = 26;
    arrayOfByte['É'] = 26;
    arrayOfByte['Ê'] = 26;
    arrayOfByte['Ë'] = 27;
    arrayOfByte['Ì'] = 27;
    arrayOfByte['Í'] = 26;
    arrayOfByte['Î'] = 24;
    arrayOfByte['Ï'] = 25;
    arrayOfByte['Ð'] = 19;
    arrayOfByte['Ñ'] = 21;
    arrayOfByte['Ò'] = 26;
    arrayOfByte['Ó'] = 27;
    arrayOfByte['Ô'] = 27;
    arrayOfByte['Õ'] = 26;
    arrayOfByte['Ö'] = 27;
    arrayOfByte['×'] = 24;
    arrayOfByte['Ø'] = 21;
    arrayOfByte['Ù'] = 21;
    arrayOfByte['Ú'] = 26;
    arrayOfByte['Û'] = 26;
    arrayOfByte['Ü'] = 28;
    arrayOfByte['Ý'] = 27;
    arrayOfByte['Þ'] = 27;
    arrayOfByte['ß'] = 27;
    arrayOfByte['à'] = 20;
    arrayOfByte['á'] = 24;
    arrayOfByte['â'] = 20;
    arrayOfByte['ã'] = 21;
    arrayOfByte['ä'] = 22;
    arrayOfByte['å'] = 21;
    arrayOfByte['æ'] = 21;
    arrayOfByte['ç'] = 23;
    arrayOfByte['è'] = 22;
    arrayOfByte['é'] = 22;
    arrayOfByte['ê'] = 25;
    arrayOfByte['ë'] = 25;
    arrayOfByte['ì'] = 24;
    arrayOfByte['í'] = 24;
    arrayOfByte['î'] = 26;
    arrayOfByte['ï'] = 23;
    arrayOfByte['ð'] = 26;
    arrayOfByte['ñ'] = 27;
    arrayOfByte['ò'] = 26;
    arrayOfByte['ó'] = 26;
    arrayOfByte['ô'] = 27;
    arrayOfByte['õ'] = 27;
    arrayOfByte['ö'] = 27;
    arrayOfByte['÷'] = 27;
    arrayOfByte['ø'] = 27;
    arrayOfByte['ù'] = 28;
    arrayOfByte['ú'] = 27;
    arrayOfByte['û'] = 27;
    arrayOfByte['ü'] = 27;
    arrayOfByte['ý'] = 27;
    arrayOfByte['þ'] = 27;
    arrayOfByte['ÿ'] = 26;
    b = arrayOfByte;
  }
  
  private Bd()
  {
    b();
  }
  
  public static Bd a()
  {
    return c;
  }
  
  private void a(int paramInt1, int paramInt2, byte paramByte)
  {
    Be localBe1 = new Be(paramInt1, paramByte);
    int n;
    for (Be localBe2 = this.d; paramByte > 8; localBe2 = Be.a(localBe2)[n])
    {
      paramByte -= 8;
      n = 0xFF & paramInt2 >>> paramByte;
      if (Be.a(localBe2) == null) {
        throw new IllegalStateException("invalid dictionary: prefix not unique");
      }
      if (Be.a(localBe2)[n] == null) {
        Be.a(localBe2)[n] = new Be();
      }
    }
    int i = 8 - paramByte;
    int j = 0xFF & paramInt2 << i;
    int k = 1 << i;
    for (int m = j; m < j + k; m++) {
      Be.a(localBe2)[m] = localBe1;
    }
  }
  
  private void b()
  {
    for (int i = 0; i < b.length; i++) {
      a(i, a[i], b[i]);
    }
  }
  
  byte[] a(byte[] paramArrayOfByte)
  {
    int i = 0;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    Be localBe1 = this.d;
    int j = 0;
    Be localBe2 = localBe1;
    int k = 0;
    while (i < paramArrayOfByte.length)
    {
      j = 0xFF & paramArrayOfByte[i] | j << 8;
      k += 8;
      while (k >= 8)
      {
        int n = 0xFF & j >>> k - 8;
        localBe2 = Be.a(localBe2)[n];
        if (Be.a(localBe2) == null)
        {
          localByteArrayOutputStream.write(Be.b(localBe2));
          k -= Be.c(localBe2);
          localBe2 = this.d;
        }
        else
        {
          k -= 8;
        }
      }
      i++;
    }
    Be localBe3;
    do
    {
      localByteArrayOutputStream.write(Be.b(localBe3));
      k -= Be.c(localBe3);
      localBe2 = this.d;
      if (k <= 0) {
        break;
      }
      int m = 0xFF & j << 8 - k;
      localBe3 = Be.a(localBe2)[m];
    } while ((Be.a(localBe3) == null) && (Be.c(localBe3) <= k));
    return localByteArrayOutputStream.toByteArray();
  }
}


/* Location:           C:\Users\dreadiscool\Desktop\tools\classes-dex2jar.jar
 * Qualified Name:     Bd
 * JD-Core Version:    0.7.0.1
 */